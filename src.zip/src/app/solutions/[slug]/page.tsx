import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import {
  ProofSection,
  type ProofSectionHeader,
} from "@/components/sections/Homepage/Proof";
import type { FooterButton } from "@/data/footer";
import type { CaseStudy } from "@/data/proof";
import { GradientLayerProvider } from "@/components/effects/GradientLayer";
import type {
  CaseStudyFooterCTA,
  CaseStudySectionBlock,
} from "@/types/caseStudyDetail";
import solutionData from "@/data/solutionPage.json";

export interface SolutionPageProps {
  params: Promise<{
    slug: string;
  }>;
}

export function generateStaticParams() {
  return [{ slug: solutionData.slug }];
}

export async function generateMetadata({
  params,
}: SolutionPageProps): Promise<Metadata> {
  const { slug } = await params;
  if (slug !== solutionData.slug) {
    return {};
  }
  return {
    title: solutionData.seo.title ?? `${solutionData.title} | Agivant`,
    description:
      solutionData.seo.description ?? solutionData.hero.summary ?? "",
  };
}

// Fallback image asset mapping for proof cards without live CMS URLs
const PROOF_IMAGES: Record<string, string> = {
  "quote-accelerator": "/images/proof/agentic-quote-accelerator.png",
  "case-quote-accelerator": "/images/proof/agentic-quote-accelerator.png",
  "sre": "/images/proof/ai-native-transformation.png",
  "case-ai-native-sre": "/images/proof/ai-native-transformation.png",
  "markets": "/images/proof/global-market-agentic-network.png",
  "case-global-markets": "/images/proof/global-market-agentic-network.png",
};

export default async function SolutionInnerPage({
  params,
}: SolutionPageProps) {
  const { slug } = await params;

  if (slug !== solutionData.slug) {
    notFound();
  }

  // 1. Follow the exact same footerCta passing pattern established by Case Study inner page
  const footerCta = solutionData.footerCta as CaseStudyFooterCTA;
  const footerButtons: FooterButton[] = [];
  if (footerCta.primaryCta?.enabled && footerCta.primaryCta.label) {
    footerButtons.push({
      label: footerCta.primaryCta.label,
      href: footerCta.primaryCta.href ?? "/ampd-score",
      variant: "dark",
      icon: "arrow-up-right",
    });
  }
  if (footerCta.secondaryCta?.enabled && footerCta.secondaryCta.label) {
    footerButtons.push({
      label: footerCta.secondaryCta.label,
      href: footerCta.secondaryCta.href ?? "/contact",
      variant: "primary",
      icon: "cube",
    });
  }

  // 2. Extract and adapt client-success section for the existing Proof/Spotlight component
  const clientSuccessSection = solutionData.sections.find(
    (s) => s.id === "client-success"
  );

  let proofHeader: ProofSectionHeader | undefined = undefined;
  if (clientSuccessSection) {
    proofHeader = {
      heading:
        clientSuccessSection.data.heading ??
        "Client success<br>in production, at scale",
      description: clientSuccessSection.data.description ?? "",
      cta: {
        label:
          clientSuccessSection.data.cta?.label ?? "See more client stories",
        href: clientSuccessSection.data.cta?.href ?? "/case-studies",
      },
    };
  }

  const caseStudies: CaseStudy[] = (
    (clientSuccessSection?.blocks as CaseStudySectionBlock[] | undefined) ?? []
  ).map((block) => {
    const imageSrc =
      block.media?.src ||
      (block.media?.assetKey && PROOF_IMAGES[block.media.assetKey]) ||
      PROOF_IMAGES[block.id] ||
      "/images/proof/agentic-quote-accelerator.png";

    const items = block.items ?? [];
    let metric: string | undefined = undefined;
    let metricLabel: string | undefined = undefined;
    let footer: string | undefined = undefined;

    if (items.length >= 3) {
      metric = items[0];
      metricLabel = items[1];
      footer = items[2];
    } else if (items.length === 1) {
      const parts = items[0].split(" ");
      metric = parts[0];
      metricLabel = parts.slice(1).join(" ");
      footer = block.id === "sre" ? "Amp'd infrastructure reliability from day one." : undefined;
    }

    return {
      id: block.id,
      industry: block.eyebrow ?? "",
      title: block.title ?? "",
      description: block.body ?? "",
      href: block.cta?.href ?? `/case-studies/${block.id}`,
      metric,
      metricLabel,
      footer,
      image: {
        src: imageSrc,
        alt: block.media?.alt || block.title || "Case study visual",
      },
    };
  });

  return (
    <GradientLayerProvider>
      <Header />

      <main id="main-content">
        {proofHeader && caseStudies.length > 0 ? (
          <ProofSection
            header={proofHeader}
            caseStudies={caseStudies}
            layout="large-right"
          />
        ) : null}
      </main>

      <Footer
        ctaData={
          solutionData.footerCta.enabled
            ? {
                heading: solutionData.footerCta.heading.replace(
                  /<br\s*\/?>/gi,
                  "\n"
                ),
                description: solutionData.footerCta.subheading ?? undefined,
                buttons: footerButtons,
              }
            : undefined
        }
      />
    </GradientLayerProvider>
  );
}
