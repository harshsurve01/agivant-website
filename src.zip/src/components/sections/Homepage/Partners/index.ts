export { Partners } from "./Partners";
