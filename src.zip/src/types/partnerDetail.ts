/**
 * src/types/partnerDetail.ts
 *
 * Types for dedicated Partner Detail Pages (/partners/[partner]).
 * CMS-ready: structured so WordPress / Headless CMS responses map
 * directly into these interfaces without modifying presentation components.
 */

export interface PartnerHeroData {
  headingLine1: string;
  headingLine2: string;
  partnerLogo: {
    src: string;
    alt: string;
    width?: number;
    height?: number;
  };
  ribbonSrc: string;
}

export interface LeadershipQuoteData {
  quote: string;
  author: {
    name: string;
    role: string;
    portraitSrc: string;
  };
}

export interface PartnerIntroData {
  heading: {
    highlight: string;
    suffix: string;
  };
  paragraphs: string[];
  leadershipQuote: LeadershipQuoteData;
  cta?: {
    label: string;
    href: string;
  };
}

export interface AgenticEnterpriseMetricsData {
  items: string[];
  closingStatement?: string;
}

export interface AgenticEnterpriseBlockData {
  id: string;
  layout?: "text-image" | "text-metrics" | "image-text";
  heading: {
    prefix?: string;
    highlight?: string;
    suffix?: string;
    text?: string;
  };
  body: string;
  closingStatement?: string;
  image?: {
    src: string;
    alt: string;
    width: number;
    height: number;
  };
  metrics?: AgenticEnterpriseMetricsData;
}

export interface AgenticEnterpriseData {
  blocks: AgenticEnterpriseBlockData[];
}

export interface AgentTeamMember {
  name: string;
  role: string;
}

export interface PartnerAccelerator {
  id: string;
  title: string;
  category: string;
  description: string;
  image: {
    src: string;
    alt: string;
  };
  challenge: string;
  solution: string;
  agentTeamTitle?: string;
  agents: AgentTeamMember[];
}

export interface PartnerSolutionsData {
  heading: {
    prefix: string;
    highlight: string;
  };
  description: string;
  accelerators: PartnerAccelerator[];
}

export interface PartnerCTAData {
  heading: string;
  description: string;
  buttonLabel: string;
  buttonHref: string;
  buttonIcon?: "cube" | "arrow-up-right";
}

export interface PartnerDetailData {
  slug: string;
  name: string;
  meta: {
    title: string;
    description: string;
  };
  hero: PartnerHeroData;
  intro: PartnerIntroData;
  agenticEnterprise?: AgenticEnterpriseData;
  solutions?: PartnerSolutionsData;
  cta?: PartnerCTAData;
}
