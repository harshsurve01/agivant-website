import caseStudyJson from "./case-study.json";
import dummyCaseStudyJson from "./case-study-dummy.json";
import type { CaseStudyDetailPage } from "@/types/caseStudyDetail";

/**
 * Case Study detail registry.
 * Future Case Studies (Case Study B, Case Study C...) can be loaded dynamically or registered here.
 * Content resides exclusively in JSON.
 */
const CASE_STUDIES_DATA: Record<string, CaseStudyDetailPage> = {
  [caseStudyJson.slug]: caseStudyJson as CaseStudyDetailPage,
  [dummyCaseStudyJson.slug]: dummyCaseStudyJson as CaseStudyDetailPage,
};

/**
 * Resolves a Case Study by its canonical slug.
 */
export async function getCaseStudyDetail(
  slug: string
): Promise<CaseStudyDetailPage | null> {
  return CASE_STUDIES_DATA[slug] ?? null;
}

/**
 * Returns all available Case Study canonical slugs for static generation.
 */
export function getAllCaseStudyDetailSlugs(): string[] {
  return Object.keys(CASE_STUDIES_DATA);
}
