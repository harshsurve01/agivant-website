import type { AmpHubData } from "@/data/ampTransformation";
import styles from "./AmpHub.module.css";

interface AmpHubProps {
  hub: AmpHubData;
}

/**
 * All geometry below is expressed in rem, and deliberately kept as
 * plain numbers that double as the SVG's viewBox units (1 viewBox
 * unit === 1rem) — so "6.5" both means 6.5rem in CSS and x=6.5 in the
 * SVG's coordinate space, with no unit conversion or percentage math
 * to keep in sync between the two.
 *
 * MUST stay in sync with .hub's width/height in AmpHub.module.css —
 * the circle's on-screen radius is what CONNECTOR_ORIGIN_X below is
 * derived from, so the lines start exactly on the circle's edge
 * instead of floating in a gap before it (the previous
 * percentage-of-self positioning drifted left of the circle at
 * certain sizes; anchoring everything to the same fixed rem values
 * the circle itself uses removes that drift entirely).
 */
const HUB_DIAMETER_REM = 9;
const HUB_RADIUS_REM = HUB_DIAMETER_REM / 2;

/** Half-width of the connector canvas: how far the outer connector
 *  dots sit from the hub's own center, toward each column. */
const REACH_REM = 11;
const CANVAS_WIDTH_REM = REACH_REM * 2;
/** Vertical room for the fan spread — sized to roughly span a
 *  multi-card column's height so the spread reads as "one line per
 *  card," without this component knowing anything about the cards
 *  themselves. */
const CANVAS_HEIGHT_REM = 14;
/** Small pull-in from the canvas's outer edge so dots don't render
 *  flush against the very edge of their own stroke. */
const EDGE_INSET_REM = 0.3;

const CENTER_X = CANVAS_WIDTH_REM / 2;
const CENTER_Y = CANVAS_HEIGHT_REM / 2;
/** Where each side's lines converge — exactly on the circle's edge,
 *  not floating in the gap before it. */
const LEFT_ORIGIN_X = CENTER_X - HUB_RADIUS_REM;
const RIGHT_ORIGIN_X = CENTER_X + HUB_RADIUS_REM;
const LEFT_OUTER_X = EDGE_INSET_REM;
const RIGHT_OUTER_X = CANVAS_WIDTH_REM - EDGE_INSET_REM;

/**
 * Returns `count` evenly spaced Y positions across the canvas height,
 * centered so a single connector still lands in the middle rather
 * than at an edge. Pure function of `count` — this is what lets
 * AmpHub render correctly whether a side has three connectors, four,
 * or any other number the data supplies, per "Do NOT assume there
 * are always four cards."
 */
function evenlySpacedY(count: number): number[] {
  if (count <= 0) return [];
  const step = CANVAS_HEIGHT_REM / (count + 1);
  return Array.from({ length: count }, (_, index) => step * (index + 1));
}

/**
 * AmpHub
 *
 * Responsible only for rendering the central circle, the "Amp'd"
 * wordmark, and the connector lines fanning out to each column — no
 * business logic, no layout awareness of AmpColumn/AmpCard.
 *
 * Connector lines are implemented as SVG (per the implementation
 * brief: "Do NOT create the connector lines using CSS... so they can
 * later be animated with Framer Motion"), not as CSS
 * borders/pseudo-elements. Each `<line>`/marker-dot pair is a single,
 * independently addressable SVG node — exactly the granularity a
 * future Framer Motion pass would need to animate them drawing in one
 * at a time.
 *
 * The connector canvas is centered on the hub's own center via
 * `top: 50%; left: 50%; transform: translate(-50%, -50%)` in
 * AmpHub.module.css — not sized as a percentage of the hub's own box
 * (see the geometry constants' comment above for why that drifted).
 * That keeps both fans symmetric around the circle regardless of
 * viewport width.
 *
 * `hub.leftConnectors`/`hub.rightConnectors` (not a hardcoded 4) drive
 * how many lines render on each side — see data/ampTransformation.ts's
 * CONTENT MODELING NOTE (connectors) for why that count lives on hub
 * itself rather than being derived from a sibling's card list.
 *
 * The wordmark's three fragments (`hub.brand.lead/body/highlight`)
 * are rendered as separate spans so each can carry its own color
 * (accent / default / brand-purple) without any text being hardcoded
 * inside this component.
 *
 * Server Component: no "use client", no hooks, no state, no animation
 * implementation at this stage — see the doc comment above.
 */
export function AmpHub({ hub }: AmpHubProps) {
  const leftYPositions = evenlySpacedY(hub.leftConnectors);
  const rightYPositions = evenlySpacedY(hub.rightConnectors);

  return (
    <div className={styles.hub}>
      <svg
        className={styles.connectors}
        viewBox={`0 0 ${CANVAS_WIDTH_REM} ${CANVAS_HEIGHT_REM}`}
        aria-hidden="true"
        focusable="false"
      >
        {leftYPositions.map((y, index) => (
          <g key={`left-${index}`} className={styles.connectorGroup}>
            <line
              x1={LEFT_ORIGIN_X}
              y1={CENTER_Y}
              x2={LEFT_OUTER_X}
              y2={y}
              className={styles.connectorLine}
            />
            <circle cx={LEFT_OUTER_X} cy={y} r={0.3} className={styles.connectorDot} />
          </g>
        ))}

        {rightYPositions.map((y, index) => (
          <g key={`right-${index}`} className={styles.connectorGroup}>
            <line
              x1={RIGHT_ORIGIN_X}
              y1={CENTER_Y}
              x2={RIGHT_OUTER_X}
              y2={y}
              className={styles.connectorLine}
            />
            <circle cx={RIGHT_OUTER_X} cy={y} r={0.3} className={styles.connectorDot} />
          </g>
        ))}
      </svg>

      <div className={styles.circle}>
        <span className={styles.logo} aria-label="Amp'd">
          <span className={styles.logoLead}>{hub.brand.lead}</span>
          <span className={styles.logoBody}>{hub.brand.body}</span>
          <span className={styles.logoHighlight}>{hub.brand.highlight}</span>
        </span>
      </div>
    </div>
  );
}
