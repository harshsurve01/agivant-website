import type { AmpHubData } from "@/data/ampTransformation";
import styles from "./AmpHub.module.css";

interface AmpHubProps {
  hub: AmpHubData;
}

/** Viewport used for the connector SVG's own coordinate space — purely
 *  an internal drawing surface, unrelated to any real pixel size. */
const VIEWBOX_SIZE = 100;
const CENTER = VIEWBOX_SIZE / 2;
/** X position each side's lines converge toward, near the circle's edge. */
const ORIGIN_OFFSET = 16;
/** X position each side's lines fan out to, near the column's cards. */
const EDGE_INSET = 2;

/**
 * Returns `count` evenly spaced Y positions across the viewBox height,
 * centered so a single connector still lands in the middle rather than
 * at an edge. Pure function of `count` — this is what lets AmpHub
 * render correctly whether a side has three connectors, four, or any
 * other number the data supplies, per "Do NOT assume there are always
 * four cards."
 */
function evenlySpacedY(count: number): number[] {
  if (count <= 0) return [];
  const step = VIEWBOX_SIZE / (count + 1);
  return Array.from({ length: count }, (_, index) => step * (index + 1));
}

/**
 * AmpHub
 *
 * Responsible only for rendering the central circle, the "Amp'd"
 * wordmark, and the connector lines fanning out to each column — no
 * business logic, no layout awareness of AmpColumn/AmpCard.
 *
 * Connector lines are implemented as SVG (per the implementation
 * brief: "Do NOT create the connector lines using CSS... so they can
 * later be animated with Framer Motion"), not as CSS
 * borders/pseudo-elements. Each `<line>`/marker-dot pair is a single,
 * independently addressable SVG node — exactly the granularity a
 * future Framer Motion pass would need to animate them drawing in one
 * at a time.
 *
 * `hub.leftConnectors`/`hub.rightConnectors` (not a hardcoded 4) drive
 * how many lines render on each side — see data/ampTransformation.ts's
 * CONTENT MODELING NOTE (connectors) for why that count lives on hub
 * itself rather than being derived from a sibling's card list.
 *
 * The wordmark's three fragments (`hub.brand.lead/body/highlight`)
 * are rendered as separate spans so each can carry its own color
 * (accent / default / brand-purple) without any text being hardcoded
 * inside this component.
 *
 * Server Component: no "use client", no hooks, no state, no animation
 * implementation at this stage — see the doc comment above.
 */
export function AmpHub({ hub }: AmpHubProps) {
  const leftYPositions = evenlySpacedY(hub.leftConnectors);
  const rightYPositions = evenlySpacedY(hub.rightConnectors);

  return (
    <div className={styles.hub}>
      <svg
        className={styles.connectors}
        viewBox={`0 0 ${VIEWBOX_SIZE} ${VIEWBOX_SIZE}`}
        preserveAspectRatio="none"
        aria-hidden="true"
        focusable="false"
      >
        {leftYPositions.map((y, index) => (
          <g key={`left-${index}`} className={styles.connectorGroup}>
            <line
              x1={CENTER - ORIGIN_OFFSET}
              y1={CENTER}
              x2={EDGE_INSET}
              y2={y}
              className={styles.connectorLine}
            />
            <circle cx={EDGE_INSET} cy={y} r={1.1} className={styles.connectorDot} />
          </g>
        ))}

        {rightYPositions.map((y, index) => (
          <g key={`right-${index}`} className={styles.connectorGroup}>
            <line
              x1={CENTER + ORIGIN_OFFSET}
              y1={CENTER}
              x2={VIEWBOX_SIZE - EDGE_INSET}
              y2={y}
              className={styles.connectorLine}
            />
            <circle
              cx={VIEWBOX_SIZE - EDGE_INSET}
              cy={y}
              r={1.1}
              className={styles.connectorDot}
            />
          </g>
        ))}
      </svg>

      <div className={styles.circle}>
        <span className={styles.logo} aria-label="Amp'd">
          <span className={styles.logoLead}>{hub.brand.lead}</span>
          <span className={styles.logoBody}>{hub.brand.body}</span>
          <span className={styles.logoHighlight}>{hub.brand.highlight}</span>
        </span>
      </div>
    </div>
  );
}
