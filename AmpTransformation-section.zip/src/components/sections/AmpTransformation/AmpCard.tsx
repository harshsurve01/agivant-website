import type { AmpCardData } from "@/data/ampTransformation";
import styles from "./AmpCard.module.css";

interface AmpCardProps {
  card: AmpCardData;
}

/**
 * AmpCard
 *
 * Reusable feature card. Responsible only for displaying its own
 * content (`card.title`) — no parent awareness, no knowledge of which
 * column it's in, no index, no offset. This is what lets AmpColumn
 * render an arbitrary number of these without any card needing to
 * know its own position.
 *
 * Server Component: no "use client", no hooks, no state, no
 * animation, no hover interaction of its own.
 */
export function AmpCard({ card }: AmpCardProps) {
  return (
    <div className={styles.card}>
      <span className={styles.title}>{card.title}</span>
    </div>
  );
}
