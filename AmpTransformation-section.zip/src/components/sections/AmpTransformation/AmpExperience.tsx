import { AmpColumn } from "./AmpColumn";
import { AmpHub } from "./AmpHub";
import type { AmpColumnData, AmpHubData } from "@/data/ampTransformation";
import styles from "./AmpExperience.module.css";

interface AmpExperienceProps {
  leftColumn: AmpColumnData;
  hub: AmpHubData;
  rightColumn: AmpColumnData;
}

/**
 * AmpExperience
 *
 * Responsible only for arranging the left column, center hub, and
 * right column side by side — no business logic, no animation. The
 * same reusable AmpColumn component renders both `leftColumn` and
 * `rightColumn`; only the data object passed to it differs, per the
 * implementation brief's "the same component must be used for both
 * left and right columns."
 *
 * Server Component: no "use client", no hooks, no state.
 */
export function AmpExperience({ leftColumn, hub, rightColumn }: AmpExperienceProps) {
  return (
    <div className={styles.experience}>
      <AmpColumn column={leftColumn} />
      <AmpHub hub={hub} />
      <AmpColumn column={rightColumn} />
    </div>
  );
}
